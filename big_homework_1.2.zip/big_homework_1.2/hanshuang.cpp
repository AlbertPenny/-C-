#include"Y.h"
#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
typedef struct tuijianproduct{
	int tuijianid;
	char tuijianname[20];
	float tuijianprice;
	char tuijianclassification[20];
	int  tuijianin;
	int tuijianout;
	int tuijianflag=1;
}tuijianshouye[8];

product *maopaopaixu(product *head)
{
if(head==NULL||head->next==NULL) return head;
product *p=NULL;
bool ischange=true;
product *jiaohuan_p=NULL;
jiaohuan_p=(product*)malloc(sizeof(product));
while(p!=head->next&&ischange)
{
    product *q=head;
    ischange=false;
    for(;q->next&&q->next!=p;q=q->next)
    {
        if(q->out > q->next->out)
        {
            memcpy(jiaohuan_p,q,sizeof(struct product));
            memcpy(q,q->next,sizeof(struct product));
            memcpy(q->next,jiaohuan_p,sizeof(struct product));
            ischange=true;
        }
    }
    p=q;
}
  return head;
}
void bagedongxi()
{
   maopaopaixu(head);
}
int main()
{
    bagedongxi();
    return 0;
}

