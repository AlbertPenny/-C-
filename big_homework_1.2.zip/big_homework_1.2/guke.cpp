#include<stdio.h>
#include<iostream>
#include"Y.h"
#include"Hanshuang.h"
using namespace std;
/*typedef struct guke{
	char name[20];
	char password[50];
	float money=0;
	char gender[5]="δ֪";
	int history1=-1;
	int history2=-1;
	int history3=-1;
	int age;
	int authority=0;
	guke *next=NULL;
};*/
/*guke_head ͷָ�� guke_tail βָ��*/
int main()
{
	sum=load();
	sum++;
	guke_xh=guke_head;
	while(guke_xh!=NULL)
	{
		cout<<guke_xh->name<<endl;
		strcpy(guke_xh->name,"halidjsdi");
		guke_xh=guke_xh->next;
	}
	//exit1();
}
