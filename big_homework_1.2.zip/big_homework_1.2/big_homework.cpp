#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<windows.h>
#include<string.h>

#include"test.h" 

char user[10]={" "};
char pass[10]={" "};
char input[11]={"          "};
char search_input[21]={"                    "};
char search[21];
char dis_area[28][35]={" ______________________________","(Search for information        )"," -Welcome----------------------",
"---------------+---------------","               |                ","               |                ","               |                ","               |                ","               |                ",
"---------------+---------------","               |                ","               |                ","               |                ","               |                ","               |                ",
"---------------+---------------","               |                ","               |                ","               |                ","               |                ","               |                ",
"---------------+---------------","               |                ","               |                ","               |                ","               |                ","               |                ",
"---------------+---------------"};
char search_area[28][35]={" ______________________________","(Search for information        )"," ------------------------------",
" -Hot sale---------------------"," ------------------------------","|                              |"," ------------------------------",
"|                              |"," ------------------------------",
"|                              |"," ------------------------------"};
char purchase_area[28][35]={" ------------------------------","                               "," ------------------------------",
" ------------------------------","|                              |","|                              |","|                              |",
"|                              |","|                              |",
"|                              |","|                              |","|                              |"
,"|                              |","|                              |","|                              |"
,"|                              |","|                              |","|                              |"
,"|                              |","|                              |","|                              |"
,"|                              |","|                              |","|                              |"
,"|                              |","|                              |","|                              |"
," ---Back (Esc)---Buy (Enter)---"};
int gotoxy(int x,int y)
{
	COORD coord = {x,y};												//operate on handle
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
	return 0;
}	
int dis()
{
	printf("\n\n\n\n\n");
    printf("               ===================LOGIN=================(X)\n");
    printf("               |                                          |\n");
    printf("               |            __________________            |\n");
    printf("               |       user:");
    printf("%s        |           |\n",input);
    printf("               |            ������������������            |\n");
    printf("               |            Password (Enter)              |\n");
    printf("               |                                          |\n");
    printf("               |            Register (Insert)             |\n"); 
    printf("               |                                          |\n");   
    printf("               |            Exit (Esc)                    |\n");
    printf("               |                                          |\n");
    printf("               +------------------------------------------+\n");
    printf("\n\n\n\n\n");

}
int dispw()
{
	printf("\n\n\n\n\n");
    printf("               ===================LOGIN=================(X)\n");
    printf("               |                                          |\n");
    printf("               |            __________________            |\n");
    printf("               |   password:");
    printf("%s        |           |\n",input);
    printf("               |            ������������������            |\n");
    printf("               |            Confirm  (Enter)              |\n");
    printf("               |                                          |\n");
    printf("               |                                          |\n");
    printf("               |                                          |\n"); 
    printf("               |            Exit (Esc)                    |\n");
    printf("               |                                          |\n");
    printf("               +------------------------------------------+\n");
    printf("\n\n\n\n\n");

}
int diserr()
{
	printf("               ############-----WARNING-----#############\n");
 	printf("               #                                        #\n");	
 	printf("               #              Input Limit !             #\n");
 	printf("               #                                        #\n");	 
	printf("               ############-----WARNING-----#############\n");   
	getch();
}
int reg()
{
	printf("\n\n\n\n\n");
    printf("               ===================REGISTER==============(X)\n");
    printf("               |                                          |\n");
    printf("               |            _________________             |\n");
    printf("               |       user:");
    printf("%s                    |\n",input);
    printf("               |                                          |\n");
    printf("               |            Confirm  (Enter)              |\n");
    printf("               |                                          |\n");
    printf("               |                                          |\n");
    printf("               |                                          |\n"); 
    printf("               |            Exit (Esc)                    |\n");
    printf("               |                                          |\n");
    printf("               +------------------------------------------+\n");
    printf("\n\n\n\n\n");

}
int regpw()
{
	printf("\n\n\n\n\n");
    printf("               ===================REGISTER==============(X)\n");
    printf("               |                                          |\n");
    printf("               |            _________________             |\n");
    printf("               |   password:");
    printf("%s                    |\n",input);
    printf("               |                                          |\n");
    printf("               |            Confirm  (Enter)              |\n");
    printf("               |                                          |\n");
    printf("               |                                          |\n");
    printf("               |                                          |\n"); 
    printf("               |            Exit (Esc)                    |\n");
    printf("               |                                          |\n");
    printf("               +------------------------------------------+\n");
    printf("\n\n\n\n\n");

}

int interface1()
{
	int i,j;
	
	printf("                                   ");
	for(i=0;i<28;i++)
	{
		for(j=0;j<35;j++)
		{
			printf("%c",dis_area[i][j]);			
		}
		printf("\n                                   ");
	}
}
int interface2()
{
	int i,j;

	printf("                                   ");
	for(i=0;i<28;i++)
	{
		for(j=0;j<35;j++)
		{
			printf("%c",search_area[i][j]);			
		}
		printf("\n                                   ");
	}	
	
 }
int interface3()
{
	int i,j;
	
	printf("                                   ");
	for(i=0;i<28;i++)
	{
		for(j=0;j<35;j++)
		{
			printf("%c",purchase_area[i][j]);			
		}
		printf("\n                                   ");
	}	
		
}
int purchase(int search_state,char *user)
{
	gotoxy(0,1);
	printf("search_state=%d",search_state);
	guke *guke_history_q=guke_head;
	while(strcmp(guke_history_q->name,user)!=0)
	{
		guke_history_q=guke_history_q->next;
	}
	char key;
	while(1)
	{		
	gotoxy(38,2);
	printf("%s",new_product[search_state].name);
	gotoxy(38,8);
	printf("�۸�%f",new_product[search_state].price);
	gotoxy(38,10);
	printf("������%d��",new_product[search_state].out);
	gotoxy(38,12);
	printf("��棺%d��",new_product[search_state].in-new_product[search_state].out); 
	


		

	key=getch();

	if(key==13)
	{

		if(guke_history_q->money>=new_product[search_state].price)
		{
			guke_history_q->money-=new_product[search_state].price;
			new_product[search_state].in--;
			new_product[search_state].out++; 

			gotoxy(38,10);
			printf("����ɹ���������%.2fԪ��",guke_history_q->money);
		}
		else if(new_product[search_state].in<=0)
		{
			gotoxy(36,16);
			printf("����ʧ�ܣ���治�㡣      ");			
		}
		else
		{

			gotoxy(36,16);
			printf("����ʧ�ܣ����㡣      ");
		}
	}
	else if(key==27)
	{
		return 0;
	}
	}    
}
int tuijianpurchase(int i,char *s)
{
	char key;
	while(1)
	{
	gotoxy(38,2);
	printf("%s",tuijianproduct[i].tuijianname);
	gotoxy(38,8);
	printf("�۸�%f",tuijianproduct[i].tuijianprice);
	gotoxy(38,10);
	printf("������%d��",tuijianproduct[i].tuijianout);
	gotoxy(38,12);
	printf("��棺%d��",tuijianproduct[i].tuijianin-tuijianproduct[i].tuijianout); 
	
	guke *guke_history_q=guke_head;
	while(strcmp(guke_history_q->name,s)!=0)
	{
		guke_history_q=guke_history_q->next;
	}


	
	
			if(guke_history_q->money<tuijianproduct[i].tuijianprice)
			{
				key=getch();
				if(key==13)
				{
				gotoxy(36,16);
				printf("����ʧ�ܣ����㡣       ");			//not enough money!
				continue;					
				}
				else if(key==27)
				{
					return 0;
				}

			}
			if(tuijianproduct[i].tuijianin-tuijianproduct[i].tuijianout<=0) 
			{
				key=getch();
				if(key==13)
				{
				gotoxy(36,16);
				printf("����ʧ�ܣ���治�㡣       ");			
				continue;					
				}
				else if(key==27)
				{
					return 0;
				}
			}
			
				key=getch();
				if(key==13)
				{
				guke_history_q->money-=tuijianproduct[i].tuijianprice;
	//			tuijianproduct[i].tuijianin--;
				tuijianproduct[i].tuijianout++; 
	
				gotoxy(36,16);
				printf("����ɹ���������%.2fԪ��",guke_history_q->money);					
				}
				else if(key==27)
				{
					return 0;
				}

	
		}

	}        

int main()
{
    char in,in2,temp;
    int i=0,regflag=0,x=14,y=17;
    int last_x,last_y;
    int search_flag=0;
    int blank_flag=0;
    int user_flag=0;
    int pass_flag=0;
    int user_state=0;
    int pass_state=0;
    int search_state=0;
    int back_flag=0;
    int back2_flag=0;
    int m=0;
    int total=0;
   
    
	sum=load();    
    total=cp();    

regis:

	regflag=0;
	search_flag=0;
	blank_flag=0;
	i=0,m=0;    
    user_flag=0;
    pass_flag=0;
    user_state=0;
    pass_state=0;
    search_state=0;
    back_flag=0;
    back2_flag=0;
    
    
    while(regflag==0)
    {
        system("cls");
        dis();
        in=getch();
			
        if(i>9)
        {
        	diserr();
        	i=9;
		}
		
        if(in==13)
        {
            break;
        }
        else if(in==27)
        {
        	return 0;
		}
		else if(in<48||(in>57&&in<65)||(in>90&&in<97)||in>122)
		{
			in2=getch();
	/*		if(in2==72)   //up
				printf("��\n");
			else if(in2==80)		//down
				printf("��\n");*/
			if(in2==82)
			{
				regflag=1;
				break;				
			}
		}
        else
        {
        	user_flag=1;
            input[i]=in;
            user[i]=in;
            i++;        	
		}
	}
	if(regflag==0)
	{
	    user[i]='\0';
	    for(i=0;i<10;i++)
	    	input[i]=' ';
	    i=0;  			
	user_state=guke_yonghuming(user);		//use this integer if possible
/* 	gotoxy(1,0);
 	printf("user=%s user_state=%d",user,user_state);
 	getch();*/
 	
 	if(user_state!=-1)
 		;
 	else
 		goto regis;
	}  
	
    while(regflag==0)
    {
        system("cls");
        dispw();
        in=getch();
        
        if(i>9)
        {
        	diserr();
        	i=9;
		}        
        
        if(in==13)
        {
            break;
        }
        else if(in==27)
        {
			return 0;
		}
        else
        {
        	pass_flag=1;
            input[i]='*';
            pass[i]=in;
            i++;       	
		}

    }
    m=0;
  //  printf("i=%d",i);
    if(regflag==0)
    {
 	   pass[++i]='\0'; 
 	//examine if pass exists   
 		pass_state=guke_mima(user_state,pass);
 		zhengsange(total);  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
/* 		gotoxy(1,0); 		
 		printf("password=%s user_state=%d pass_state=%d",pass,user_state,pass_state);
 		getch();*/
 		
		if(!pass_state)
		{
			for(m=0;m<i;m++)
				input[m]=' ';
			diserr();//error
			goto regis;
		}
		else
		{
			guke *guke_temp_p=NULL;
			guke_temp_p=guke_head;
			while(strcmp(guke_temp_p->name,user))
			{
				guke_temp_p=guke_temp_p->next;
			}
			gotoxy(1,0); 	
	/*		cout<<guke_temp_p->name<<guke_temp_p->authority<<endl;
			getch();*/
			if(guke_temp_p->authority==0)
			{
				regflag=2;
			/*	cout<<regflag<<endl;
				getch();*/
			}
		}
		  //ccomplished
	
	} 
	
	
		   
    while(regflag==1)
    {
        system("cls");
        reg();
        in=getch();

        if(i>9)
        {
        	diserr();
        	i=9;
		}
		
        if(in==13)
        {
            break;
        }
        else if(in==27)
        {
        	return 0;
		}
		else if(in<48||(in>57&&in<65)||(in>90&&in<97)||in>122)
		{
			in2=getch();
			if(in2==82)
			{
				regflag=1;
				break;				
			}
		}
        else
        {
        	user_flag=1;
            input[i]=in;
            user[i]=in;
            i++;        	
		}
	}
	if(regflag==1)
	{
		
	    user[i]='\0';
	    for(i=0;i<10;i++)
	    	input[i]=' ';
	    i=0;  		
	}
  
    while(regflag==1)
    {
        system("cls");
        regpw();
        in=getch();
        
        if(i>9)
        {
        	diserr();
        	i=9;
		}        
        
        if(in==13)
        {
            break;
        }
        else if(in==27)
        {
			return 0;
		}
        else
        {
        	pass_flag=1; 
            input[i]='*';
            pass[i]=in;
            i++;       	
		}
    }
    if(regflag==1)
 	   pass[i]='\0';
    
 //   puts(user);
 //   puts(pass);
 	if(user_flag==0||pass_flag==0)
 	{
 		diserr();
 		goto regis;
	}
    
  /*  if(strcmp(user," ")||strcmp(pass," "))
    {
    	diserr();
    	goto regis;
	}*/
	
	//examine users here
    
	i=0;
	while(1&&regflag!=2)
	{
		geinibage(total);
		
		blank_flag=0;	
		system("cls");
		
		sprintf(&dis_area[6][0],"%6s",tuijianproduct[0].tuijianname);
		sprintf(&dis_area[6][24],"%6s",tuijianproduct[1].tuijianname);
		sprintf(&dis_area[12][0],"%6s",tuijianproduct[2].tuijianname);
		sprintf(&dis_area[12][24],"%6s",tuijianproduct[3].tuijianname);
		sprintf(&dis_area[18][0],"%6s",tuijianproduct[4].tuijianname);
		sprintf(&dis_area[18][24],"%6s",tuijianproduct[5].tuijianname);
		sprintf(&dis_area[24][0],"%6s",tuijianproduct[6].tuijianname);
		sprintf(&dis_area[24][24],"%6s",tuijianproduct[7].tuijianname);
						   	
	    interface1();	
	    
		gotoxy(0,3);
		printf("Welcome %s !",user);
		gotoxy(0,1);
		printf("total=%d",total);
		
		//items insert here��rand per login, not per transfer pages,but you can add figures if possible�� 

	    while(1)
	    {
	    	back2_flag=0;
	/*		search_flag=0;
			blank_flag=0;
	//		i=0,m=0;    
	//	    user_flag=0;
	//	    pass_flag=0;
	//	    user_state=0;
	//	    pass_state=0;
		    search_state=0;
		    back_flag=0;*/
	    //  
			gotoxy(0,2);printf("x=%d y=%d   ",x,y);
			temp=dis_area[x][y];
	 		dis_area[x][y]='*';
	 		
	 		last_x=x;
	 		last_y=y;
	
			in=getch();
			in2=0;
			if((in<48&&in!=13)||(in>57&&in<65)||(in>90&&in<97)||in>122)
				in2=getch();
	 
			if(in2==72&&(x>0))		//up
			{
				x--;
			}
			else if(in2==80&&(x<27))	//down	
			{
				x++;
			}
			else if(in2==75&&(y>0))      //left
			{
				y--;
			}
			else if(in2==77&&(y<30))	 //right
			{
				y++;
			}
			else
				;
				
			dis_area[last_x][last_y]=temp;
			
			gotoxy(last_y+36,last_x);
			printf("\b%c",temp);		
			
			gotoxy(y+36,x);
			printf("\b*");
			gotoxy(y+35,x);
			
			if(in==13)
			{
				if(x>=0&&x<=2&&y>=0&&y<=31)
				{
					search_flag=1;
					break;
				}
				else if(x>=4&&x<=8&&y>=0&&y<=14)
				{
					system("cls");
					interface3();
					tuijianpurchase(0,user);
					back2_flag=1;
				//	printf("1\n");
				}
				else if(x>=4&&x<=8&&y>=16&&y<=31)
				{
					system("cls");
					interface3();
					tuijianpurchase(1,user);
					back2_flag=1;
				}
				else if(x>=10&&x<=14&&y>=0&&y<=14)
				{
					system("cls");
					interface3();
					tuijianpurchase(2,user);
					back2_flag=1;
				}
				else if(x>=10&&x<=14&&y>=16&&y<=31)
				{
					system("cls");
					interface3();
					tuijianpurchase(3,user);
					back2_flag=1;
				}
				else if(x>=16&&x<=20&&y>=0&&y<=14)
				{
					system("cls");
					interface3();
					tuijianpurchase(4,user);
					back2_flag=1;
				}
				else if(x>=16&&x<=20&&y>=16&&y<=31)
				{
					system("cls");
					interface3();
					tuijianpurchase(5,user);
					back2_flag=1;
				}
				else if(x>=22&&x<=26&&y>=0&&y<=14)
				{
					system("cls");
					interface3();
					tuijianpurchase(6,user);
					back2_flag=1;
				}
				else if(x>=22&&x<=26&&y>=16&&y<=31)
				{
					system("cls");
					interface3();
					tuijianpurchase(7,user);
					back2_flag=1;
				}
				
			}
			if(back2_flag==1)
				break;
	

		/*	in=getch();
	
	        if(i>20)
	        {
	        	diserr();
	        	i=20;
			}
			else if(in==13)
			{
				
			}
			else
			{
				search[i]=in;
				search_input[i]=in;
				i++;			
			}*/
	
		}
		if(back2_flag==1)
			continue;
psearch:
		int select=1;
		if(search_flag)
		{
			i=0;
			system("cls");   	
		    interface2();	
		
			gotoxy(2,10);
			printf("Welcome %s !",user);
			gotoxy(36,1);
			for(i=0;i<10;i++)
				input[i]=' ';
			
			gotoxy(38,5);//inits three historical items here��tthe num is relative�� 
			printf("%s",tuijianproduct[8].tuijianname);
			gotoxy(38,7);
			printf("%s",tuijianproduct[9].tuijianname);
			gotoxy(38,9);
			printf("%s",tuijianproduct[10].tuijianname);
		}
		
		i=0;
		select=0;		
		while(search_flag)
		{
			in2=0;		

			gotoxy(0,1);printf("select=%d",select);
			if(select==0)
			{
				gotoxy(0,1);
				printf("Search=                     ");
				gotoxy(7,1);		
			//	printf("000");
				gotoxy(37,5);	printf("\b ");
				gotoxy(37,7);	printf("\b ");
				gotoxy(37,9);	printf("\b ");
   
    			in=getch();
				if(in==-32)
				{
		//			printf("in2 scaned.");
					in2=getch();				
				}
				else if(in==13)
				{
		//send	
					in2=-1;
					gotoxy(7,1);
					puts(search);//Sent the search[] out;
					blank_flag=0;
					break;			
				}
				else if(in==27)
				{
	
					for(i=0;i<10;i++)
						search[i]='\0';
					i=0;
					back_flag=1;
					blank_flag=0;
					break;
				}	
				else
				{
					in2=-1;
				//	select=0;
					back_flag=0;
					input[i]=in;
					
					if(!blank_flag)
					{
					gotoxy(36,1);
					printf("                      ");	
					blank_flag=1;			
					}
		
					gotoxy(37+i,1);
					printf("%c",in);
					if(in2==8&&i>=0)
					{
						gotoxy(36+i,1);
						printf(" \b");
						search[--i]='\0';
					}
					else if(i<0)
					{
						i++;					
						continue;
					}
					else
					{
						search[i]=in;
						i++;					
					}
					
					//search here
					
				}
   			
				if(in2==72)
				{
					select=3;
				}
				else if(in2==80)
				{
					select=1;					
				}
				
			}
			else if(select==1)
			{
				gotoxy(0,1);
				printf("Search=                     ");
				gotoxy(7,1);
			//	printf("111");
				gotoxy(37,5);	printf("\b*");
				gotoxy(37,7);	printf("\b ");
				gotoxy(37,9);	printf("\b ");
				
	    		in=getch();
				if(in==-32)
				{
		//			printf("in2 scaned.");
					in2=getch();				
				}
				else if(in==27)
				{
	
					for(i=0;i<10;i++)
						search[i]='\0';
					i=0;
					back_flag=1;
					break;
				}
				else if(in==13)
				{
		//	enter
					in2=-1;
					system("cls");
					interface3();
					tuijianpurchase(8,user);
					break;			
				}
				else
				{
		//			printf("in2 not scanned.");	
					in2=-1;			
				}
   			
				if(in2==72)
				{
					select=0;
				}
				else if(in2==80)
				{
					select=2;					
				}
								
			}
			else if(select==2)
			{
				gotoxy(0,1);
				printf("Search=                     ");
				gotoxy(7,1);
			//	printf("222");
				gotoxy(37,5);	printf("\b ");
				gotoxy(37,7);	printf("\b*");
				gotoxy(37,9);	printf("\b ");	
				
	    		in=getch();
				if(in==-32)
				{
		//			printf("in2 scaned.");
					in2=getch();				
				}
				else if(in==27)
				{
	
					for(i=0;i<10;i++)
						search[i]='\0';
					i=0;
					back_flag=1;
					break;
				}
				else if(in==13)
				{
		//	enter
					in2=-1;	
					system("cls");
					interface3();
					tuijianpurchase(9,user);
					break;		
				}
				else
				{
					in2=-1;						
				}
   			
				if(in2==72)
				{
					select=1;
				}
				else if(in2==80)
				{
					select=3;					
				}
							
			}
			else if(select==3)
			{
				gotoxy(0,1);
				printf("Search=                     ");
				gotoxy(7,1);
			//	printf("333");
				gotoxy(37,5);	printf("\b ");
				gotoxy(37,7);	printf("\b ");
				gotoxy(37,9);	printf("\b*");
	
	    		in=getch();
				if(in==-32)
				{
		//			printf("in2 scaned.");
					in2=getch();				
				}
				else if(in==27)
				{
	
					for(i=0;i<10;i++)
						search[i]='\0';
					i=0;
					back_flag=1;
					break;
				}
				else if(in==13)
				{
		//	enter
					in2=-1;	
					system("cls");
					interface3();
					tuijianpurchase(10,user);
					break;		
				}
				else
				{
					in2=-1;						
				}
   			
				if(in2==72)
				{
					select=2;
				}
				else if(in2==80)
				{
					select=0;					
				}
								
			}

		}
		if(back_flag==0)
		{
			search_state=guke_sousuo(user_state,search);	//temporarily puts here;
			gotoxy(0,5);
			printf("search_state=%d",search_state);
			getch();
			getch();
			if(search_state==-1)
			{
				gotoxy(47,20);
				printf("No data.");
				getch();
				gotoxy(47,20);
				printf("        ");
				for(m=0;m<10;m++)
				{
					search[m]='\0';
				}
				goto psearch;
			}
			else
			{
				system("cls");
				interface3();
				for(m=0;m<10;m++)
				{
					search[m]='\0';
				}
				purchase(search_state,user);
			}			
		}
		else
		;

				

	}
	if(regflag==2)
	{
		administrator();
	}
    
    return 0;
}

