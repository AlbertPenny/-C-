#include<stdio.h>
#include<iostream>
#include"Y.h"
#include"Hanshuang.h"
#include"test.h"
using namespace std;
/*typedef struct guke{L
	char name[20];
	char password[50];
	float money=0;
	char gender[5]="δ֪";
	int history1=-1;
	int history2=-1;
	int history3=-1;
	int age;
	int authority=0;
	guke *next=NULL;
};*/
/*guke_head ͷָ�� guke_tail βָ��*/
int main()
{
	char a[20],b[20];
	sum=load();
	sum++;
	guke_xh=guke_head;
	while(guke_xh!=NULL)
	{
		cout<<guke_xh->name<<endl;
	//	strcpy(guke_xh->name,"halidjsdi");
		guke_xh=guke_xh->next;
	}
		gets(a);
		cout<<guke_yonghuming(a);
		gets(b);
		cout<<guke_mima(guke_yonghuming(a),b);
	//exit1();
}
