#ifndef TEST_H//���ã���ֹ���ظ�����
#define TEST_H
#include<stdio.h>
#include<time.h>
#include<malloc.h>
#include<string.h>
#include"Y.h"

struct product new_product[100];
struct tuijianxianshi{
	int tuijianid;
	char tuijianname[20];
	float tuijianprice;
	char tuijianclassification[20];
	int tuijianin;
	int tuijianout;
	int tuijianflag=1;
}tuijianproduct[13];

int cp()
{
//	char a[20];
	int cnt=0,jishu=0;
	product *h=head;
	while(h!=tail)
	{

		memcpy(&new_product[cnt],h,sizeof(struct product));
		h=h->next;
		 jishu++;
		 cnt++;
	}
	memcpy(&new_product[cnt],h,sizeof(struct product));
	jishu++;
	return jishu;
//	geinibage(jishu);
//	gets(a);
}
/* ��½�����������û��������򷵻صڼ����û�������û����������򷵻�-1*/
int guke_yonghuming(char *shuru)
{

//	printf("%s",shuru);
//	getch();
    guke *guke_chazhao_p=NULL;
	guke_chazhao_p=(guke*)malloc(sizeof(guke));
	int i=0;
	guke_chazhao_p=guke_head;
	while(guke_chazhao_p!=guke_tail)
	{
		++i;
		if(strcmp(guke_chazhao_p->name,shuru)==0)
	  	return i;
		//cout<<guke_chazhao_p->name<<endl;
		guke_chazhao_p=guke_chazhao_p->next;
	}
	return -1;
}
/* ƥ���û��������룬����Գɹ��򷵻�1����Բ��ɹ��򷵻�0*/
int guke_mima(int i,char *b)
{
    guke *guke_mima_p=NULL;
	guke_mima_p=(guke*)malloc(sizeof(guke));
	int j=1;
	guke_mima_p=guke_head;
	while(j!=i)
	{
	j++;
	guke_mima_p=guke_mima_p->next;
	}
	if(strcmp(guke_mima_p->password,b)==0)
	  return 1;
	return 0;
}
void geinibage(int jishu)
{
	int i;
    int sum0=sum;
	int a=0;
	srand(time(0));
	for(i=0;i<8;i++)
	{
		a=rand()%(jishu-1)+0;
          //printf("a=%d\n",a);
		memcpy(&tuijianproduct[i],&new_product[a],sizeof(struct tuijianxianshi));
        //printf("%s\n",tuijianproduct[i].tuijianname);
	}
	return;
}
int guke_sousuo(int i,char *c)
{
    product *product_sousuo_p=NULL;
    product_sousuo_p=(product*)malloc(sizeof(product));
    product_sousuo_p=head;
    int j=0;
	while(product_sousuo_p!=tail)
	{
	++j;
	if(strcmp(product_sousuo_p->name,c)==0)
	  return j;
	product_sousuo_p=product_sousuo_p->next;
	}
	return -1;
}
void zhengsange(int jishu)
{
	int i,j,t;
	char q[40];
	float p;
	for(i=0;i<jishu-1;i++)
        for(j=0;j<jishu-1-i;j++)
        {
        if(new_product[j].out<new_product[j+1].out)
    {
       t=new_product[j].id;
       new_product[j].id=new_product[j+1].id;
       new_product[j+1].id= t;
       strcpy(q,new_product[j].name);
       strcpy(new_product[j].name,new_product[j+1].name);
       strcpy(new_product[j+1].name,q);
       p=new_product[j].price;
       new_product[j].price=new_product[j+1].price;
       new_product[j+1].price=p;
       strcpy(q,new_product[j].classification);
       strcpy(new_product[j].classification,new_product[j+1].classification);
       strcpy(new_product[j+1].classification,q);
       t=new_product[j].in;
       new_product[j].in=new_product[j+1].in;
       new_product[j+1].in=t;
       t=new_product[j].out;
       new_product[j].out=new_product[j+1].out;
       new_product[j+1].out=t;
       t=new_product[j].flag;
       new_product[j].flag=new_product[j+1].flag;
       new_product[j+1].flag= t;
    }
    else if(new_product[j].out==new_product[j+1].out&&new_product[j].in<new_product[j+1].in)
        {
       t=new_product[j].id;
       new_product[j].id=new_product[j+1].id;
       new_product[j+1].id= t;
       strcpy(q,new_product[j].name);
       strcpy(new_product[j].name,new_product[j+1].name);
       strcpy(new_product[j+1].name,q);
       p=new_product[j].price;
       new_product[j].price=new_product[j+1].price;
       new_product[j+1].price=p;
       strcpy(q,new_product[j].classification);
       strcpy(new_product[j].classification,new_product[j+1].classification);
       strcpy(new_product[j+1].classification,q);
       t=new_product[j].in;
       new_product[j].in=new_product[j+1].in;
       new_product[j+1].in=t;
       t=new_product[j].out;
       new_product[j].out=new_product[j+1].out;
       new_product[j+1].out=t;
       t=new_product[j].flag;
       new_product[j].flag=new_product[j+1].flag;
       new_product[j+1].flag= t;
    }
        }
    /*for(i=0;i<13;i++)
        printf("%s out:%d in:%d %d\n",new_product[i].name,new_product[i].out,new_product[i].in,new_product[i].id);*/
    for(i=8,j=0;i<11;i++,j++)
    {
        memcpy(&tuijianproduct[i],&new_product[j],sizeof(new_product));
         //printf("%d\n",tuijianproduct[i].tuijianid);
     }
}
#endif
